print("hello world")

message = "Go Gators"
print (message)

message = "Go Clemson Tigers"
print (message)
