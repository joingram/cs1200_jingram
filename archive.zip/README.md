# Feedback

See feedback for lab 3.0 [here](https://github.com/joingram/cs1200_jingram/commit/02291bc7f875b3fca63fd817a0625c2b673d8184)